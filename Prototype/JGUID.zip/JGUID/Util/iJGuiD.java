package Util;
import java.io.File;


public interface iJGuiD
{
	public void startNewProject(String type);
	public void openExistingProject(File f);
	public void showProjectDialog();
}
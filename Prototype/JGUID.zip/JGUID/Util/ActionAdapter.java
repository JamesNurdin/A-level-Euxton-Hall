package Util;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

//Overrides  - No Action
public class ActionAdapter implements ActionListener 
{
	public void actionPerformed(ActionEvent ae)
	{
	}
}

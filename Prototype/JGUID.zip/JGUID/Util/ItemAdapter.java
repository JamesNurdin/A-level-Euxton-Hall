package Util;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

//Overrides  - No Action
public class ItemAdapter implements ItemListener
{
	public void itemStateChanged(ItemEvent e)
	{
	}
}
